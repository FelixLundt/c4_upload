def generate_move(board, player, timeout):
    return 0